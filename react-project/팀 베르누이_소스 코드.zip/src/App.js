import "./App.css";
// import Bar from "./d3/4_Bar";
import ShowAll from "./ShowAll";

function App() {
  return (
    <div>
      <ShowAll />
    </div>
  );
}

export default App;
